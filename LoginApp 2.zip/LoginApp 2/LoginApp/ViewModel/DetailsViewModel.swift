//
//  DetailsViewModel.swift
//  LoginApp
//
//  Created by Bargav Munusamy Sampath on 28/02/21.
//

import Foundation

class DetailsViewModel:NSObject{
    var name:String?
    var code:String?
    
    init(data:DetailsModel){
        self.name = data.name
        self.code = data.code
    }
}

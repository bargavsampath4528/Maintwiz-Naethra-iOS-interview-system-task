//
//  DetailsPageViewController.swift
//  LoginApp
//
//  Created by Bargav Munusamy Sampath on 28/02/21.
//

import UIKit

class DetailsPageViewController: UIViewController {
    
    @IBOutlet weak var codeTextField: UITextField!
    @IBOutlet weak var nameTextField: UITextField!
    
    var name = ""
    var code = ""
    
    var editingStatus = false
    var addingStatus = false
    
    var delegate:DataTransferFromDetailsPageDelegate!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUp()
    }
}

extension DetailsPageViewController{
    func setUp(){
        print("Inside Details Page")
        nameTextField.attributedPlaceholder = NSAttributedString(string: "Name",attributes: [NSAttributedString.Key.foregroundColor: UIColor.white])
        codeTextField.attributedPlaceholder = NSAttributedString(string: "Code",attributes: [NSAttributedString.Key.foregroundColor: UIColor.white])
        nameTextField.text = name
        codeTextField.text = code
        
        if editingStatus {
            print("editing")
            codeTextField.isUserInteractionEnabled = false
        }
        if addingStatus{
            print("adding")
        }
    }
    @IBAction func cancelButtonPressed(_ sender: UIButton) {
        editingStatus = false
        addingStatus = false
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func saveButtonPressed(_ sender: UIButton) {
        let data = DetailsModel(name: nameTextField.text!, code: codeTextField.text!)
        delegate.updateTableView(data: data, addingStatus:addingStatus, editingStatus:editingStatus)
        addingStatus = false
        editingStatus = false
        self.navigationController?.popViewController(animated: true)
    }
}

//
//  WebService.swift
//  LoginApp
//
//  Created by Bargav Munusamy Sampath on 28/02/21.
//

import Foundation

class WebServices:NSObject{
    
    static let sharedInstance = WebServices()
    
    //    func getDetails(completion:@escaping([DetailsModel]?,Error?)->()){
    //        let urlString = "https://newsapi.org/v2/top-headlines?country=us&apiKey=99e01e68784b4b8ba22432145257c121"
    //        guard let url = URL(string:urlString)else{return}
    //        URLSession.shared.dataTask(with:url){(data,response,error) in
    //         if let error = error{
    //             completion(nil,error)
    //         }
    //         guard let data = data else{return}
    //          do{
    //              var details = [DetailsModel]()
    //              let services = try JSONDecoder().decode(DataModel.self,from:data)
    //              details = services.data.map{return $0}
    //              completion(details,nil)
    //           }
    //          catch let error{
    //              print(error.localizedDescription)
    //          }
    //        }.resume()
    //    }
    
    func getDetails(completion:@escaping([[String:Any]]?,Error?)->()){
        //For GET Request
        
        let configuration = URLSessionConfiguration .default
        let session = URLSession(configuration: configuration)
        
        
        let urlString = NSString(format: "http://webserv.maintwiz.co.in/ws/services/list_facility_test")
        
        print("get wallet balance url string is \(urlString)")
        //let url = NSURL(string: urlString as String)
        let request : NSMutableURLRequest = NSMutableURLRequest()
        request.url = NSURL(string: NSString(format: "%@", urlString) as String) as URL?
        request.httpMethod = "POST"
        request.timeoutInterval = 30
        
        //request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        
        let dataTask = session.dataTask(with: request as URLRequest) {
            (data: Data?, response: URLResponse?, error: Error?) -> Void in
            
            // 1: Check HTTP Response for successful GET request
            guard let httpResponse = response as? HTTPURLResponse, let receivedData = data
            else {
                print("error: not a valid http response")
                return
            }
            
            switch (httpResponse.statusCode)
            {
            case 200:
                
                let response = NSString (data: receivedData, encoding: String.Encoding.utf8.rawValue)
                //print("response is \(response)")
                
                
                do {
                    let getResponse = try JSONSerialization.jsonObject(with: receivedData, options: .allowFragments) as! [String:Any]
                    let x = getResponse["List Facility"] as! [String:Any]
                    //print(x)
                    let y = x["Facility List"] as! [[String:Any]]
                    //print(((y[0]) as AnyObject).count)
                    //print(y)
                    completion(y,error)
                    
                    // }
                } catch {
                    print("error serializing JSON: \(error)")
                }
                
                break
            case 400:
                
                break
            default:
                print("wallet GET request got response \(httpResponse.statusCode)")
            }
        }
        dataTask.resume()
    }
}

//func getRequest(){
//    //For GET Request
//
//    let configuration = URLSessionConfiguration .default
//    let session = URLSession(configuration: configuration)
//
//
//    let urlString = NSString(format: "http://webserv.maintwiz.co.in/ws/services/list_facility_test")
//
//    print("get wallet balance url string is \(urlString)")
//    //let url = NSURL(string: urlString as String)
//    let request : NSMutableURLRequest = NSMutableURLRequest()
//    request.url = NSURL(string: NSString(format: "%@", urlString) as String) as URL?
//    request.httpMethod = "POST"
//    request.timeoutInterval = 30
//
//    //request.addValue("application/json", forHTTPHeaderField: "Content-Type")
//    request.addValue("application/json", forHTTPHeaderField: "Accept")
//
//    let dataTask = session.dataTask(with: request as URLRequest) {
//        (data: Data?, response: URLResponse?, error: Error?) -> Void in
//
//        // 1: Check HTTP Response for successful GET request
//        guard let httpResponse = response as? HTTPURLResponse, let receivedData = data
//        else {
//            print("error: not a valid http response")
//            return
//        }
//
//        switch (httpResponse.statusCode)
//        {
//        case 200:
//
//            let response = NSString (data: receivedData, encoding: String.Encoding.utf8.rawValue)
//            //print("response is \(response)")
//
//
//            do {
//                let getResponse = try JSONSerialization.jsonObject(with: receivedData, options: .allowFragments) as! [String:Any]
//                let x = getResponse["List Facility"] as! [String:Any]
//                //print(x)
//                let y = x["Facility List"] as! [[String:Any]]
//                //print(((y[0]) as AnyObject).count)
//                //print(y)
//                self.k = y.map{return $0}
//                print(self.k.count)
//
//                // }
//            } catch {
//                print("error serializing JSON: \(error)")
//            }
//
//            break
//        case 400:
//
//            break
//        default:
//            print("wallet GET request got response \(httpResponse.statusCode)")
//        }
//    }
//    dataTask.resume()
//}
//}

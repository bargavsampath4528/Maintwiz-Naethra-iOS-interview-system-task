//
//  ViewController.swift
//  LoginApp
//
//  Created by Bargav Munusamy Sampath on 27/02/21.
//

import UIKit

class LoginPageViewController: UIViewController {
    
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUp()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        emailTextField.text = ""
        passwordTextField.text = ""
    }
}

extension LoginPageViewController{
    func setUp(){
        emailTextField.attributedPlaceholder = NSAttributedString(string: "Username",attributes: [NSAttributedString.Key.foregroundColor: UIColor.white])
        passwordTextField.attributedPlaceholder = NSAttributedString(string: "Password",attributes: [NSAttributedString.Key.foregroundColor: UIColor.white])
    }
    func showAlert(message1:String,message2:String){
        let alert = UIAlertController(title:message2, message: message1, preferredStyle: .alert)
        let action = UIAlertAction(title: "Dismiss", style:.cancel)
        alert.addAction(action)
        present(alert,animated: true)
    }
    
    @IBAction func loginButtonPressed(_ sender: UIButton) {
        let errorMsg = "Invalid Credentials"
        let (validEmailid,validPswd) = ("admin","admin")
        guard let emailid = emailTextField.text else{
            return
        }
        guard !emailid.isEmpty, emailid == validEmailid  else{
            showAlert(message1:"Enter valid email Id",message2:errorMsg)
            return
        }
        guard let pswd = passwordTextField.text else{return}
        guard !pswd.isEmpty, pswd == validPswd else{
            showAlert(message1: "Enter valid password", message2:errorMsg)
            return
        }
        print("successful login")
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let listVC = storyBoard.instantiateViewController(withIdentifier: "ListViewController") as! ListViewController
        self.navigationController?.pushViewController(listVC, animated: true)
    }
}


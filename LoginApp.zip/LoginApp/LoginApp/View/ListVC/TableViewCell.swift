//
//  TableViewCell.swift
//  LoginApp
//
//  Created by Bargav Munusamy Sampath on 27/02/21.
//

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet weak var editButton: UIButton!
    
    @IBOutlet weak var codeLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    
    var delegate:DataTransferFromCellDelegate!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    @IBAction func editButtonPressed(_ sender: UIButton) {
        print(sender.tag)
        delegate.detailsPage(rowNo: sender.tag)
    }
    
    func configureCell(cell:TableViewCell,rowNo:Int, details:[[String:Any]]){
         cell.backgroundColor = .systemGray5
         cell.selectionStyle = .none
         cell.editButton.tag = rowNo
         cell.nameLabel.text = (details[rowNo])["fac_name"] as? String
         cell.codeLabel.text = (details[rowNo])["fac_code"] as? String 
    }
    
}

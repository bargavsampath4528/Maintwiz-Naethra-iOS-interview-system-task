//
//  ListViewController.swift
//  LoginApp
//
//  Created by Bargav Munusamy Sampath on 27/02/21.
//

import UIKit

class ListViewController: UIViewController {
    
    @IBOutlet weak var detailsCountLbl: UILabel!
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var tableView: UITableView!
    let cellId = "TableViewCell"
    var detailsVModel = [DetailsViewModel]()
    var rowToBeEdited:Int?
    var details = [[String:Any]]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.isHidden = true
        searchBarConfig()
        setUp()
        getDataFromService()
    }
}

extension ListViewController:UITableViewDataSource,UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return details.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: cellId, for: indexPath) as! TableViewCell
        cell.delegate = self
        cell.configureCell(cell:cell, rowNo:indexPath.row, details:details)
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
}

extension ListViewController:DataTransferFromCellDelegate{
    func detailsPage(rowNo:Int) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let detailsVC = storyBoard.instantiateViewController(withIdentifier: "DetailsPageViewController") as! DetailsPageViewController
        detailsVC.name = (details[rowNo])["fac_name"] as! String
        detailsVC.code = (details[rowNo])["fac_code"] as! String
        detailsVC.editingStatus = true
        detailsVC.delegate = self
        rowToBeEdited = rowNo
        self.navigationController?.pushViewController(detailsVC, animated: true)
    }
}

extension ListViewController:DataTransferFromDetailsPageDelegate{
    func updateTableView(data: DetailsModel, addingStatus:Bool, editingStatus:Bool) {
        if addingStatus{
            let data = DetailsViewModel(data: data)
            let newData = [["fac_id":"0","fac_name":data.name,"fac_code":data.code]]
            self.details.append(contentsOf: newData)
            self.detailsCountLbl.text = "\(details.count)"
            self.tableView.beginUpdates()
            self.tableView.insertRows(at: [IndexPath.init(row: self.details.count-1, section: 0)], with: .automatic)
            self.tableView.endUpdates()
            self.tableView.reloadData()
        }
        if editingStatus {
            guard let rowNo = rowToBeEdited else{return}
            (details[rowNo])["fac_name"] = data.name
            self.tableView.reloadData()
        }
    }
}

extension ListViewController{
    
    @IBAction func backButton(_ sender: UIButton) {
        self.navigationController?.popToRootViewController(animated: true)
    }
    
    @IBAction func addButtonPressed(_ sender: UIButton) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let detailsPageVC = storyBoard.instantiateViewController(withIdentifier: "DetailsPageViewController") as! DetailsPageViewController
        detailsPageVC.addingStatus = true
        detailsPageVC.delegate = self
        self.navigationController?.pushViewController(detailsPageVC, animated: true)
    }
    
    func getDataFromService(){
        WebServices.sharedInstance.getDetails{(details,error) in
            if error == nil {
                self.details = details?.map{return $0} ?? []
                print(self.details.count)
                DispatchQueue.main.async{
                    self.detailsCountLbl.text = String(self.details.count)
                    self.tableView.reloadData()
                }
            }
        }
    }
    
    func setUp(){
        let cellNib = UINib(nibName: cellId, bundle: nil)
        tableView.register(cellNib, forCellReuseIdentifier: cellId)
        tableView.layer.borderColor = UIColor.black.cgColor
        tableView.layer.borderWidth = 2.0
        detailsCountLbl.text = ""
    }
    
    func searchBarConfig(){
        self.searchBar.backgroundColor = UIColor.white
        self.searchBar.layer.borderWidth = 3
        self.searchBar.layer.borderColor = UIColor.black.cgColor
        self.searchBar.layer.backgroundColor = UIColor.white.cgColor
        self.searchBar.tintColor = UIColor(red: 0.3, green: 0.63, blue: 0.22, alpha: 1)
    }
}

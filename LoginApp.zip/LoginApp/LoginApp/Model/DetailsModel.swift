//
//  DetailsModel.swift
//  LoginApp
//
//  Created by Bargav Munusamy Sampath on 28/02/21.
//

import Foundation

class DetailsModel:Codable {
    var name:String?
    var code:String?
    
    //dependency injection
    init(name:String,code:String){
        self.name = name
        self.code = code
    }
}

class DataModel:Decodable{
    var data = [DetailsModel]()
    init(data:[DetailsModel]){
        self.data = data
    }
}

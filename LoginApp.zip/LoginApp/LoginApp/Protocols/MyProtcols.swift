//
//  MyProtcols.swift
//  LoginApp
//
//  Created by Bargav Munusamy Sampath on 01/03/21.
//

import Foundation

protocol DataTransferFromCellDelegate {
    func detailsPage(rowNo:Int)
}

protocol DataTransferFromDetailsPageDelegate {
    func updateTableView(data:DetailsModel, addingStatus:Bool, editingStatus:Bool)
}
